
# GOBI S AI Portfolio

## Features
- Modern AI Portfolio
- Responsive Design
- Animated UI
- Contact Form
- Backend API
- Glassmorphism Cards
- Machine Learning Project Showcase

## Frontend
Open frontend/index.html

## Backend Setup
cd backend
npm install
npm start

Server runs at:
http://localhost:5000
