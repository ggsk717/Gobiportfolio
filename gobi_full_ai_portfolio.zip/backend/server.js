
const express = require('express');
const cors = require('cors');

const app = express();

app.use(cors());
app.use(express.json());

app.get('/', (req,res)=>{
    res.send('Portfolio Backend Running');
});

app.post('/contact', (req,res)=>{
    console.log(req.body);
    res.json({message:'Message received'});
});

app.listen(5000, ()=>{
    console.log('Server running on port 5000');
});
